import React, { useEffect, useState } from "react";
import Webcam from "react-webcam";
import cv from "@techstark/opencv-js";

import "./App.css";
import { processImage } from "./imageProcessing";

const videoConstraints: any = {
  width: 128,
  height: 72,
  facingMode: "environment",
};

function App() {
  const webcamRef: any = React.useRef(null);
  const imgRef: any = React.useRef(null);
  const faceImgRef: any = React.useRef(null);
  const [isActive, setIsActive] = useState(false);
  const [detectedPixels, setDetectedPixels] = useState(0);
  const [time, setTime] = useState(0);

  useEffect(() => {
    let interval: any = null;

    if (isActive) {
      interval = setInterval(() => {
        setTime((time) => time + 10);
        if (detectedPixels < 1000) {
          stopTimer();
        }
      }, 10);
    } else {
      clearInterval(interval);
    }

    return () => {
      clearInterval(interval);
    };
  }, [isActive, detectedPixels]);

  useEffect(() => {
    const process = async () => {
      const imageSrc = webcamRef?.current?.getScreenshot();
      if (!imageSrc) return;

      return new Promise((resolve: any) => {
        imgRef.current.src = imageSrc;
        imgRef.current.onload = () => {
          try {
            const img = cv.imread(imgRef.current);
            setDetectedPixels(processImage(img));
            cv.imshow(faceImgRef.current, img);

            img.delete();
            resolve();
          } catch (error) {
            console.log(error);
            resolve();
          }
        };
      });
    };

    let handle: any;
    const nextTick = () => {
      handle = requestAnimationFrame(async () => {
        await process();
        nextTick();
      });
    };
    nextTick();
    return () => {
      cancelAnimationFrame(handle);
    };
  }, []);

  const startTimer = () => {
    setIsActive((value) => !value);
  };

  const stopTimer = () => {
    setIsActive(false);
  };

  const resetTimer = () => {
    setIsActive(false);
    setTime(0);
  };

  return (
    <div className="App">
      <div className="camera">
        <Webcam
          ref={webcamRef}
          className="webcam"
          mirrored
          screenshotFormat="image/jpeg"
          style={{ position: "absolute" }}
          videoConstraints={videoConstraints}
        />
        <img
          className="inputImage"
          alt="input"
          ref={imgRef}
          style={{ opacity: 0, position: "absolute", top: 0, left: 0 }}
        />
        <canvas
          className="outputImage"
          ref={faceImgRef}
          style={{
            // position: "absolute",
            // top: 0,
            // left: 0,
            // width: "100%",
            width: 300,
            height: 400,
          }}
        />
      </div>
      <div style={{ alignContent: "center", width: "100%", marginTop: 20 }}>
        <span>{("0" + Math.floor((time / 1000) % 60)).slice(-2)}.</span>
        <span>{("0" + ((time / 10) % 100)).slice(-2)}</span>
        <br />
        <br />
        {/* <span>{detectedPixels}</span> */}
        <br />
        <br />
        <button onClick={startTimer}>START</button>
        <br />
        <br />
        <button onClick={resetTimer}>RESET</button>
      </div>
    </div>
  );
}

export default App;
